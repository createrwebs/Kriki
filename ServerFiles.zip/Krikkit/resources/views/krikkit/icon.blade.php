@props([
    'name' => 'check',
    'variant' => 'outline',
])

@php
    $map = [
        'x' => 'x-mark',
        'search' => 'magnifying-glass',
        'info' => 'information-circle',
        'warning' => 'exclamation-triangle',
        'upload' => 'arrow-up-tray',
        'dots' => 'ellipsis-horizontal',
        'circle' => 'stop',
        'prohibit' => 'empty',
        'ban' => 'empty',
    ];

    $icon = $map[$name] ?? $name;
    $class = $attributes->get('class', '');
    $hasSize = is_string($class) && preg_match('/(?:^|\s)size-/', $class);
@endphp

{{-- Color via currentColor: inherit parent (buttons → accent-foreground / white on base). --}}
@if ($icon === 'lab')
    <svg
        {{ $attributes->class(['shrink-0', 'size-5' => ! $hasSize]) }}
        viewBox="0 0 24 24"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-hidden="true"
    >
        <path
            fill="none"
            stroke="currentColor"
            stroke-linecap="round"
            stroke-linejoin="round"
            stroke-width="2"
            d="M12 5v4M8 2h2a2 2 0 0 1 2 2v1h-2a2 2 0 0 1-2-2zm8.815 20h-9.63a1.185 1.185 0 0 1-1.029-1.773L10 13.5V9h4v4.5l3.844 6.727A1.185 1.185 0 0 1 16.814 22M9 9h6m1-6h-2a2 2 0 0 0-2 2v1h2a2 2 0 0 0 2-2z"
        />
    </svg>
@elseif ($icon === 'github')
    <svg
        {{ $attributes->class(['shrink-0', 'size-5' => ! $hasSize]) }}
        viewBox="0 0 640 640"
        fill="currentColor"
        fill-rule="evenodd"
        clip-rule="evenodd"
        xmlns="http://www.w3.org/2000/svg"
        aria-hidden="true"
    >
        <path d="M319.988 7.973C143.293 7.973 0 151.242 0 327.96c0 141.392 91.678 261.298 218.826 303.63 16.004 2.964 21.886-6.957 21.886-15.414 0-7.63-.319-32.835-.449-59.552-89.032 19.359-107.8-37.772-107.8-37.772-14.552-36.993-35.529-46.831-35.529-46.831-29.032-19.879 2.209-19.442 2.209-19.442 32.126 2.245 49.04 32.954 49.04 32.954 28.56 48.922 74.883 34.76 93.131 26.598 2.882-20.681 11.15-34.807 20.315-42.803-71.08-8.067-145.797-35.516-145.797-158.14 0-34.926 12.52-63.485 32.965-85.88-3.33-8.078-14.291-40.606 3.083-84.674 0 0 26.87-8.61 88.029 32.8 25.512-7.075 52.878-10.642 80.056-10.76 27.2.118 54.614 3.673 80.162 10.76 61.076-41.386 87.922-32.8 87.922-32.8 17.398 44.08 6.485 76.631 3.154 84.675 20.516 22.394 32.93 50.953 32.93 85.879 0 122.907-74.883 149.93-146.117 157.856 11.481 9.921 21.733 29.398 21.733 59.233 0 42.792-.366 77.28-.366 87.804 0 8.516 5.764 18.473 21.992 15.354 127.076-42.354 218.637-162.274 218.637-303.582 0-176.695-143.269-319.988-320-319.988l-.023.107z" />
    </svg>
@elseif ($icon === 'empty')
    <svg
        {{ $attributes->class(['shrink-0', 'size-5' => ! $hasSize]) }}
        viewBox="0 0 256 256"
        fill="currentColor"
        xmlns="http://www.w3.org/2000/svg"
        aria-hidden="true"
    >
        <path d="M198.24,62.63l15.68-17.25a8,8,0,0,0-11.84-10.76L186.4,51.86A95.95,95.95,0,0,0,57.76,193.37L42.08,210.62a8,8,0,1,0,11.84,10.76L69.6,204.14A95.95,95.95,0,0,0,198.24,62.63ZM48,128A80,80,0,0,1,175.6,63.75l-107,117.73A79.63,79.63,0,0,1,48,128Zm80,80a79.55,79.55,0,0,1-47.6-15.75l107-117.73A79.95,79.95,0,0,1,128,208Z" />
    </svg>
@else
    @php
        $prefix = match ($variant) {
            'solid' => 'heroicon-s-',
            'mini' => 'heroicon-m-',
            default => 'heroicon-o-',
        };
        $component = $prefix.$icon;
    @endphp
    <x-dynamic-component
        :component="$component"
        {{ $attributes->class(['shrink-0', 'size-5' => ! $hasSize]) }}
        aria-hidden="true"
    />
@endif
